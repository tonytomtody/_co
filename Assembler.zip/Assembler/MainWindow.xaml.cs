﻿using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assembler
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        bool error = false;
        short t = 16,offset = 0;

        public void resetDic() {
            t = 16;
            offset = 0;
            aDic = new Dictionary<string, short>()
            {
                { "SCEEN",16384},
                { "KBD",24576},
                { "SP",0},
                { "LCL",1},
                { "AG",2},
                { "THIS",3},
                { "THAT",4 }
            };
        }

        Dictionary<string, short> aDic = new Dictionary<string, short>()
        {
            { "SCEEN",16384},
            { "KBD",24576},
            { "SP",0},
            { "LCL",1},
            { "AG",2},
            { "THIS",3},
            { "THAT",4 }
        };
        Dictionary<string, string> compDic = new Dictionary<string, string>()
        {   {"0","0101010"},
            { "1","0111111"},
            { "-1","0111010"},
            { "D","0001100"},
            { "A","0110000"},
            { "!D","0001101"},
            { "!A","0110001"},
            { "-D","0001111"},
            { "-A","0110011"},
            { "D+1","0011111"},
            { "A+1","0110111"},
            { "D-1","0001110"},
            { "A-1","0110010"},
            { "D+A","0000010"},
            { "D-A","0010011"},
            { "A-D","0000111"},
            { "D&A","0000000"},
            { "D|A","0010101"},
            { "M","1110000"},
            { "!M","1110001"},
            { "-M","1110011"},
            { "M+1","1110111"},
            { "M-1","1110010"},
            { "D+M","1000010"},
            { "D-M","1010011"},
            { "M-D","1000111"},
            { "D&M","1000000"},
            { "D|M","1010101"}
        };

        Dictionary<string, string> destDic = new Dictionary<string, string>()
        {
            { "M","001"},
            { "D","010"},
            { "DM","011"},
            { "A","100"},
            { "AM","101"},
            { "AD","110"},
            { "ADM","111"}
        };

        Dictionary<string, string> jumpDic = new Dictionary<string, string>()
        {
            { "JGT","001"},
            { "JEQ","010"},
            { "JGE","011"},
            { "JLT","100"},
            { "JNE","101"},
            { "JLE","110"},
            { "JMP","111"}
        };

        private void btnAssemble_Click(object sender, RoutedEventArgs e)
        {
            resetDic();
            txtOutput.Text = "";
            error = false;
            string[] txt = loadInput();
            for (short i = 0; i < txt.Length; i++)
            {
                if (txt[i] == "")
                {
                    offset += 1;
                    continue;
                }
                if (error)
                {
                    return;
                }
                if (isA(txt[i]))
                {
                    astructure(txt[i]);
                }
                else
                {
                    cinstruDic(txt[i]);
                }
            }
            
        }

        private bool isA(string txt)
        {
            if (txt[0] == '@')
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private string[] loadInput()
        {
            string txt = txtInput.Text;
            txt = txt.Replace("\r", "");
            txt = txt.Replace(" ", "");
            string[] lines = txt.Split('\n');
            for (short i = 0; i < lines.Length; i++)
            {
                if (lines[i].Contains("//"))
                {
                    string[] parts = lines[i].Split("//");
                    lines[i] = parts[0];
                }
                if (lines[i] == "")
                {
                    offset += 1;
                }
                if (lines[i].Contains("("))
                {
                    string line = lines[i].Replace("(", "");
                    line = line.Replace(")", "");
                    if (!aDic.ContainsKey(line))
                    {
                        aDic.Add(line, (short)(i - offset));
                    }
                    lines[i] = "";
                    offset += 1;
                }
            }
            return lines;
        }

        private void astructure(string txt)
        {
            txt = txt.Replace("@", "");
            txt = txt.Replace("R", "");
            bool isNum = int.TryParse(txt, out int n);
            if (isNum)
            {
                string binary = Convert.ToString(n, 2).PadLeft(16,'0');
                txtOutput.Text += binary;
                txtOutput.Text += "\n";
            }
            else if (aDic.ContainsKey(txt))
            {
                string binary = Convert.ToString(aDic[txt], 2).PadLeft(16, '0');
                txtOutput.Text += binary;
                txtOutput.Text += "\n";
            }
            else
            {
                aDic.Add(txt, t);
                string binary = Convert.ToString(t, 2).PadLeft(16, '0');
                txtOutput.Text += binary;
                txtOutput.Text += "\n";
                t++;
                return;
            }
        }

        private void cinstruDic(string txt)
        {
            string[] parts = txt.Split("=");
            string comp = null, jump = null, dest = null;
            if (parts.Length == 2)
            {
                dest = parts[0];
                string[] parts2 = parts[1].Split(";");
                if (parts2.Length == 2)
                {
                    comp = parts2[0];
                    jump = parts2[1];
                }
                else if (parts2.Length == 1)
                {
                    comp = parts[1];
                    jump = null;
                }
                else
                {
                    error = true;
                    return;
                }
            }
            else if (parts.Length == 1)
            {
                string[] parts2 = parts[0].Split(";");
                if (parts2.Length == 2)
                {
                    comp = parts2[0];
                    jump = parts2[1];
                }
                else if (parts2.Length == 1)
                {
                    comp = parts[0];
                    jump = null;
                }
                else
                {
                    error = true;
                    return;
                }
            }
            else
            {
                error = true;
                return;
            }
            txtOutput.Text += "111";
            if (comp == null)
            {
                error = true;
                return;
            }
            else if (compDic.ContainsKey(comp))
            {
                txtOutput.Text += compDic[comp];
            }
            else
            {
                error = true;
                return;
            }
            if (dest == null)
            {
                txtOutput.Text += "000";
            }
            else if (destDic.ContainsKey(dest))
            {
                txtOutput.Text += destDic[dest];
            }
            else
            {
                error = true;
                return;
            }
            if (jump == null)
            {
                txtOutput.Text += "000";
            }
            else if (jumpDic.ContainsKey(jump))
            {
                txtOutput.Text += jumpDic[jump];
            }
            else
            {
                error = true;
                return;
            }
            txtOutput.Text += "\n";
        }

        private void cstructure(string txt)
        {
            string[] parts = txt.Split("=");
            string comp = null, jump = null, dest = null;
            if (parts.Length == 2)
            {
                dest = parts[0];
                string[] parts2 = parts[1].Split(";");
                if (parts2.Length == 2)
                {
                    comp = parts2[0];
                    jump = parts2[1];
                }
                else if (parts2.Length == 1)
                {
                    comp = parts[1];
                    jump = null;
                }
                else
                {
                    error = true;
                    return;
                }
            }
            else if (parts.Length == 1)
            {
                string[] parts2 = parts[0].Split(";");
                if (parts2.Length == 2)
                {
                    comp = parts2[0];
                    jump = parts2[1];
                }
                else if (parts2.Length == 1)
                {
                    comp = parts[0];
                    jump = null;
                }
                else
                {
                    error = true;
                    return;
                }
            }
            else
            {
                error = true;
                return;
            }
            txtOutput.Text += "111";
            if (comp == "0")
            {
                txtOutput.Text += "0101010";
            }
            else if (comp == "1")
            {
                txtOutput.Text += "0111111";
            }
            else if (comp == "-1")
            {
                txtOutput.Text += "0111010";
            }
            else if (comp == "D")
            {
                txtOutput.Text += "0001100";
            }
            else if (comp == "A")
            {
                txtOutput.Text += "0110000";
            }
            else if (comp == "!D")
            {
                txtOutput.Text += "0001101";
            }
            else if (comp == "!A")
            {
                txtOutput.Text += "0110001";
            }
            else if (comp == "-D")
            {
                txtOutput.Text += "0001111";
            }
            else if (comp == "-A")
            {
                txtOutput.Text += "0110011";
            }
            else if (comp == "D+1")
            {
                txtOutput.Text += "0011111";
            }
            else if (comp == "A+1")
            {
                txtOutput.Text += "0110111";
            }
            else if (comp == "D-1")
            {
                txtOutput.Text += "0001110";
            }
            else if (comp == "A-1")
            {
                txtOutput.Text += "0110010";
            }
            else if (comp == "D+A")
            {
                txtOutput.Text += "0000010";
            }
            else if (comp == "D-A")
            {
                txtOutput.Text += "0010011";
            }
            else if (comp == "A-D")
            {
                txtOutput.Text += "0000111";
            }
            else if (comp == "D&A")
            {
                txtOutput.Text += "0000000";
            }
            else if (comp == "D|A")
            {
                txtOutput.Text += "0010101";
            }
            else if (comp == "M")
            {
                txtOutput.Text += "1110000";
            }
            else if (comp == "!M")
            {
                txtOutput.Text += "1110001";
            }
            else if (comp == "-M")
            {
                txtOutput.Text += "1110011";
            }
            else if (comp == "M+1")
            {
                txtOutput.Text += "1110111";
            }
            else if (comp == "M-1")
            {
                txtOutput.Text += "1110010";
            }
            else if (comp == "D+M")
            {
                txtOutput.Text += "1000010";
            }
            else if (comp == "D-M")
            {
                txtOutput.Text += "1010011";
            }
            else if (comp == "M-D")
            {
                txtOutput.Text += "1000111";
            }
            else if (comp == "D&M")
            {
                txtOutput.Text += "1000000";
            }
            else if (comp == "D|M")
            {
                txtOutput.Text += "1010101";
            }
            else
            {
                error = true;
                return;
            }
            if (dest == null)
            {
                txtOutput.Text += "000";
            }
            else if (dest == "M")
            {
                txtOutput.Text += "001";
            }
            else if (dest == "D")
            {
                txtOutput.Text += "010";
            }
            else if (dest == "DM")
            {
                txtOutput.Text += "011";
            }
            else if (dest == "A")
            {
                txtOutput.Text += "100";
            }
            else if (dest == "AM")
            {
                txtOutput.Text += "101";
            }
            else if (dest == "AD")
            {
                txtOutput.Text += "110";
            }
            else if (dest == "ADM")
            {
                txtOutput.Text += "111";
            }
            else
            {
                error = true;
                return;
            }
            if (jump == null)
            {
                txtOutput.Text += "000";
            }
            else if (jump == "JGT")
            {
                txtOutput.Text += "001";
            }
            else if (jump == "JEQ")
            {
                txtOutput.Text += "010";
            }
            else if (jump == "JGE")
            {
                txtOutput.Text += "011";
            }
            else if (jump == "JLT")
            {
                txtOutput.Text += "100";
            }
            else if (jump == "JNE")
            {
                txtOutput.Text += "101";
            }
            else if (jump == "JLE")
            {
                txtOutput.Text += "110";
            }
            else if (jump == "JMP")
            {
                txtOutput.Text += "111";
            }
            else
            {
                error = true;
                return;
            }
            txtOutput.Text += "\n";
        }
    }
}